![](http://i.imgur.com/lnyo4rM.jpg)
## VouchJS

#### some previews of some bot actions

![](http://i.imgur.com/7M32aep.png)

![](http://i.imgur.com/yJWtLCC.png)

##### feature list

- [x] vouching for users
- [x] top listing
- [x] single list of vouches 
- [x] set count of vouches in user nickname  
- [x] blocking users
- [x] get access to #marketplace after X vouches
- [ ] removing vouch(s) by user
- [ ] removing vouch(s) by Date


##### improvement/bug list

- [x] don't check for every vouch user in naming handler
- [ ] marketplace role granting after X vouches (5)
- [ ] bump - watcher
- [ ] text update (vouch help)
- [ ] improve vote vouch 
- [ ] outdated single list text
